#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Miscellaneous utilities
"""

import numbers
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Optional, Union

import librosa
import mido
import numpy as np
import partitura
from partitura.score import ScoreLike
from partitura.utils.music import to_quarter_tempo

# Tempo marking to BPM mapping
# Reference: https://en.wikipedia.org/wiki/Tempo#Basic_tempo_markings
TEMPO_MARKING_TO_BPM = {
    # Very slow (24-40 BPM)
    "larghissimo": 24,
    "grave": 30,
    # Slow (40-66 BPM)
    "largo": 40,
    "larghetto": 50,
    "lento": 60,
    # Slow-moderate (44-80 BPM)
    "adagio": 60,
    "adagietto": 70,
    # Walking pace (56-108 BPM)
    "andante": 80,
    "andantino": 90,
    # Moderate (86-126 BPM)
    "moderato": 110,
    "allegretto": 120,
    # Fast (100-156 BPM)
    "allegro": 130,
    # Very fast (136-200+ BPM)
    "vivace": 150,
    "vivacissimo": 170,
    "presto": 180,
    "prestissimo": 200,
}


def extract_tempo_marking_from_musicxml(
    score_file: Union[str, Path],
) -> Optional[float]:
    """
    Extract tempo from text tempo marking (e.g., "Allegro", "Andante") in MusicXML.

    Parses <direction-type><words>...</words></direction-type> elements and
    matches against known tempo markings. The tempo is adjusted based on the
    time signature to return quarter-note BPM.

    Handles both simple and compound meters:
    - Simple meters (2/2, 4/4, etc.): beat is the note indicated by denominator
    - Compound meters (6/8, 9/8, 12/8): beat is a dotted note (3 subdivisions)

    For example:
    - 2/2 "Allegro" (130 half notes/min) → 260 quarter-note BPM
    - 6/8 "Presto" (180 dotted-quarters/min) → 270 quarter-note BPM

    Parameters
    ----------
    score_file : str or Path
        Path to the MusicXML file

    Returns
    -------
    float or None
        Quarter-note BPM based on tempo marking, or None if not found
    """
    try:
        tree = ET.parse(str(score_file))
        root = tree.getroot()

        # Track current time signature
        # Default to 4/4 (simple meter, quarter note beat)
        current_beats = 4
        current_beat_type = 4

        # Process measures in order to track time signature changes
        for part in root.iter("part"):
            for measure in part.iter("measure"):
                # Check for time signature change in this measure
                for attributes in measure.iter("attributes"):
                    for time_elem in attributes.iter("time"):
                        beats_elem = time_elem.find("beats")
                        beat_type_elem = time_elem.find("beat-type")
                        if beats_elem is not None and beats_elem.text:
                            current_beats = int(beats_elem.text)
                        if beat_type_elem is not None and beat_type_elem.text:
                            current_beat_type = int(beat_type_elem.text)

                # Look for tempo marking in this measure
                for direction in measure.iter("direction"):
                    for direction_type in direction.iter("direction-type"):
                        for words in direction_type.iter("words"):
                            if words.text:
                                text = words.text.lower().strip()
                                # Check each tempo marking
                                for marking, bpm in TEMPO_MARKING_TO_BPM.items():
                                    # Match if marking appears at the start of the text
                                    if re.match(rf"^{marking}\b", text):
                                        # Check if compound meter (6/8, 9/8, 12/8, etc.)
                                        # Compound meter: numerator divisible by 3 and >= 6
                                        is_compound = (
                                            current_beats >= 6
                                            and current_beats % 3 == 0
                                        )

                                        if is_compound:
                                            # Compound meter: beat is dotted note
                                            # e.g., 6/8: dotted quarter = 3 eighth notes
                                            # To maintain the same "feel" as simple meter:
                                            # - In 4/4 "Andante=80": quarter = 0.75s
                                            # - In 6/8 we want dotted quarter as beat
                                            # - dotted quarter = 1.5 × quarter
                                            # - So dotted quarter BPM = quarter BPM / 1.5
                                            quarter_note_bpm = bpm / 1.5
                                        else:
                                            # Simple meter: beat-type indicates beat note
                                            # Convert to quarter-note BPM
                                            # beat-type 2 (half note): multiply by 2
                                            # beat-type 4 (quarter note): no change
                                            # beat-type 8 (eighth note): divide by 2
                                            quarter_note_bpm = bpm * (
                                                4.0 / current_beat_type
                                            )

                                        return float(quarter_note_bpm)

                # Only process first part to avoid duplicates
                break
    except Exception:
        pass

    return None


def ensure_rng(
    seed: Union[numbers.Integral, np.random.RandomState],
) -> np.random.RandomState:
    """
    Ensure random number generator is a np.random.RandomState instance

    Parameters
    ----------
    seed : int or np.random.RandomState
        An integer to serve as the seed for the random number generator or a
        `np.random.RandomState` instance.

    Returns
    -------
    rng : np.random.RandomState
        A random number generator.
    """

    if isinstance(seed, numbers.Integral):
        rng = np.random.RandomState(seed)
        return rng
    elif isinstance(seed, np.random.RandomState):
        rng = seed
        return rng
    else:
        raise ValueError(
            "`seed` should be an integer or an instance of "
            f"`np.random.RandomState` but is {type(seed)}"
        )


def get_window_indices(indices: np.ndarray, context: int) -> np.ndarray:
    # Create a range array from -context to context (inclusive)
    range_array = np.arange(-context, context + 1)

    # Reshape indices to be a column vector (len(indices), 1)
    indices = indices[:, np.newaxis]

    # Use broadcasting to add the range array to each index
    out_array = indices + range_array

    return out_array.astype(int)


def is_audio_file(file_path) -> bool:
    audio_extensions = {".wav", ".mp3", ".flac", ".aac", ".ogg", ".m4a"}
    ext = Path(file_path).suffix
    return ext.lower() in audio_extensions


def is_midi_file(file_path) -> bool:
    midi_extensions = {".mid", ".midi"}
    ext = Path(file_path).suffix
    return ext.lower() in midi_extensions


def set_latency_stats(
    latency: float, latency_stats: Dict[str, float], count: int
) -> Dict[str, float]:
    latency_stats["total_latency"] += latency
    latency_stats["total_frames"] = count
    latency_stats["max_latency"] = max(latency_stats["max_latency"], latency)
    latency_stats["min_latency"] = min(latency_stats["min_latency"], latency)

    return latency_stats


def interleave_with_constant(
    array: np.array,
    constant_row: float = 0,
) -> np.ndarray:
    """
    Interleave a matrix with rows of a constant value.

    Parameters
    -----------
    array : np.ndarray
    """
    # Determine the shape of the input array
    num_rows, num_cols = array.shape

    # Create an output array with interleaved rows (double the number of rows)
    interleaved_array = np.zeros((num_rows * 2, num_cols), dtype=array.dtype)

    # Set the odd rows to the original array and even rows to the constant_row
    interleaved_array[0::2] = array
    interleaved_array[1::2] = constant_row

    return interleaved_array


def get_tempo_from_score(
    score_part: ScoreLike,
    score_file: Optional[Union[str, Path]] = None,
) -> Optional[float]:
    """
    Extract first tempo marking from score if available.

    Tries multiple sources in order:
    1. Partitura Tempo objects (explicit BPM)
    2. MusicXML <sound tempo="..."/> element (if score_file provided)
    3. Text tempo marking (e.g., "Allegro", "Andante") converted to approximate BPM

    Parameters
    ----------
    score_part : ScoreLike
        Partitura score part
    score_file : str or Path, optional
        Path to the score file. Used as fallback to parse MusicXML directly
        when partitura doesn't extract tempo.

    Returns
    -------
    float or None
        Tempo in BPM if found in score, None otherwise.
    """
    # Try partitura Tempo objects first
    if score_part is not None:
        try:
            for tempo_obj in score_part.iter_all(partitura.score.Tempo):
                if hasattr(tempo_obj, "bpm") and tempo_obj.bpm is not None:
                    # the marking's unit ("h" = 100 is 200 quarters per minute)
                    return float(to_quarter_tempo(tempo_obj.unit or "q", tempo_obj.bpm))
        except Exception:
            pass

    # Fallback: parse MusicXML directly for <sound tempo="..."/>
    if score_file is not None:
        try:
            import xml.etree.ElementTree as ET

            tree = ET.parse(str(score_file))
            root = tree.getroot()

            for sound_elem in root.iter("sound"):
                tempo_attr = sound_elem.get("tempo")
                if tempo_attr is not None:
                    return float(tempo_attr)
        except Exception:
            pass

    # Fallback: extract from text tempo marking (e.g., "Allegro", "Andante")
    if score_file is not None:
        text_tempo = extract_tempo_marking_from_musicxml(score_file)
        if text_tempo is not None:
            return text_tempo

    return None


def get_tempo_at_beat(
    score_part: ScoreLike,
    beat: float,
    default_tempo: float = 120.0,
) -> float:
    """
    Get tempo (BPM) at a specific beat position in the score.

    Uses score tempo markings if available. Falls back to default_tempo otherwise.

    Parameters
    ----------
    score_part : ScoreLike
        Partitura score part
    beat : float
        Beat position in the score
    default_tempo : float
        Default tempo to use if no tempo markings found

    Returns
    -------
    float
        Tempo in BPM at the given beat position
    """
    if score_part is None:
        return default_tempo

    # Collect all tempo markings with their positions
    tempo_changes = []
    try:
        for tempo_obj in score_part.iter_all(partitura.score.Tempo):
            if hasattr(tempo_obj, "bpm") and tempo_obj.bpm is not None:
                # Get beat position of tempo marking
                start_time = getattr(tempo_obj, "start", None)
                if start_time is not None:
                    tempo_beat = score_part.beat_map(start_time.t)
                    tempo_changes.append((tempo_beat, float(tempo_obj.bpm)))
    except Exception:
        pass

    if not tempo_changes:
        return default_tempo

    # Sort by beat position
    tempo_changes.sort(key=lambda x: x[0])

    # Find the tempo at the given beat (last tempo marking before or at beat)
    current_tempo = default_tempo
    for tempo_beat, bpm in tempo_changes:
        if tempo_beat <= beat:
            current_tempo = bpm
        else:
            break

    return current_tempo


def get_current_note_bpm(score: ScoreLike, onset_beat: float, tempo: float) -> float:
    """Get the adjusted BPM for a given note onset beat position based on time signature."""
    current_time = score.inv_beat_map(onset_beat)
    beat_type_changes = [
        {"start": time_sig.start, "beat_type": time_sig.beat_type}
        for time_sig in score.time_sigs
    ]

    # Find the latest applicable time signature change
    latest_change = next(
        (
            change
            for change in reversed(beat_type_changes)
            if current_time >= change["start"].t
        ),
        None,
    )

    # Return adjusted BPM if time signature change exists, else default tempo
    return latest_change["beat_type"] / 4 * tempo if latest_change else tempo


def generate_score_audio(score: ScoreLike, bpm: float, samplerate: int):
    bpm_array = [
        [onset_beat, get_current_note_bpm(score, onset_beat, bpm)]
        for onset_beat in score.note_array()["onset_beat"]
    ]
    bpm_array = np.array(bpm_array)
    score_audio = partitura.save_wav_fluidsynth(
        score,
        bpm=bpm_array,
        samplerate=samplerate,
    )

    first_onset_in_beat = score.note_array()["onset_beat"].min()
    first_onset_in_time = (
        score.inv_beat_map(first_onset_in_beat)
        / score.quarter_duration_map(score.inv_beat_map(first_onset_in_beat))
        * (60 / bpm)
    )
    # add padding to the beginning of the score audio
    padding_size = int(first_onset_in_time * samplerate)
    score_audio = np.pad(score_audio, (padding_size, 0))

    last_onset_in_div = np.floor(score.note_array()["onset_div"].max())
    last_onset_in_time = (
        last_onset_in_div
        / score.quarter_duration_map(score.inv_beat_map(last_onset_in_div))
        * (60 / bpm)
    )

    buffer_size = 0.1  # for assuring the last onset is included (in seconds)
    last_onset_in_time += buffer_size
    score_audio = score_audio[: int(last_onset_in_time * samplerate)]
    return score_audio
