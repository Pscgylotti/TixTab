#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Wrapper around parangonar (https://github.com/sildater/parangonar) online
note matchers so they can be plugged into the Matchmaker pipeline.

Supported method keys:
  - "SL_OLTW"  : parangonar.OLTWMatcher  (symbolic-level OLTW)
  - "SLT_OLTW" : parangonar.TOLTWMatcher (symbolic-level tempo OLTW)
  - "OTM"      : parangonar.OnlineTransformerMatcher
  - "OPTM"     : parangonar.OnlinePureTransformerMatcher
"""

from typing import Generator

import numpy as np
import parangonar as pa
import partitura as pt

from matchmaker.base import OnlineAlignment
from matchmaker.features.processor import Processor
from matchmaker.utils.typing import InputMIDIFrame
from typing import Optional, Tuple


_OLTW_MATCHERS = {"SL_OLTW", "SLT_OLTW"}
_TRANSFORMER_MATCHERS = {"OTM", "OPTM"}


def _ensure_unique_ids(note_array: np.ndarray, prefix: str) -> np.ndarray:
    """Guarantee unique string ids in the note array, copying if needed."""
    ids = note_array["id"]
    if len(set(ids)) == len(ids) and all(bool(i) for i in ids):
        return note_array
    out = note_array.copy()
    out["id"] = np.array([f"{prefix}{i}" for i in range(len(out))])
    return out


def _initial_beat_period(note_array: np.ndarray) -> float:
    """TOLTWMatcher's own starting tempo, 90 quarters per minute, in s/beat.

    TOLTWMatcher reads beats-per-quarter off the first note by onset, which is
    0/0 when that note is a grace note, and a NaN starting tempo never tracks.
    This takes the same reading from the first note that has a duration.
    """
    notes = np.sort(note_array, order="onset_beat")
    notes = notes[notes["duration_quarter"] > 0]
    beat_per_quarter = notes["duration_beat"][0] / notes["duration_quarter"][0]
    return 60 / 90 / beat_per_quarter


class OnlineParangonarAlignment(OnlineAlignment):
    """
    Adapter that exposes a parangonar online matcher through the
    `OnlineAlignment` interface Matchmaker expects.

    Parameters
    ----------
    reference_features : np.ndarray
        Score note array (structured, with `onset_beat`, `pitch`, `id`,
        `is_grace`).
    method : str
        One of {"SL_OLTW", "SLT_OLTW", "OTM", "OPTM"}.
    queue : RECVQueue or None
        The MidiStream queue. Drained but not used; kept so Matchmaker's
        stream lifecycle stays intact.
    """

    def __init__(
        self,
        reference_features: np.ndarray,
        method: str,
        queue=None,
        **kwargs
    ):
        if method not in _OLTW_MATCHERS | _TRANSFORMER_MATCHERS:
            raise ValueError(f"Unknown parangonar method: {method}")
        score_note_array = _ensure_unique_ids(reference_features, prefix="s")
        score_positions = np.unique(score_note_array["onset_beat"]).astype(np.float32)
        super().__init__(
            reference_features=reference_features,
            score_positions=score_positions,
            queue=queue,
        )
        self.method = method
        self.score_note_array = score_note_array
        self.matcher = self._build_matcher(method, self.score_note_array, **kwargs)
        
    @staticmethod
    def _build_matcher(method: str, sna: np.ndarray, **kwargs):
        if method == "SLT_OLTW":
            kwargs.setdefault("init_tempo", _initial_beat_period(sna))
            return pa.TOLTWMatcher(sna, tracker_type=method, **kwargs)
        if method == "SL_OLTW":
            return pa.OLTWMatcher(sna,tracker_type=method, **kwargs)
        if method == "OTM":
            return pa.OnlineTransformerMatcher(sna, **kwargs)
        if method == "OPTM":
            return pa.OnlinePureTransformerMatcher(sna, **kwargs)
        raise ValueError(method)

    def step(self, performance_note) -> None:
        # The transformer matchers can step past the last score onset.
        index = int(self.matcher(performance_note))
        self.current_index = min(max(index, 0), len(self.score_positions) - 1)


class ParangonarProcessor(Processor):
    """Aggregate ``note_on`` events in a MIDI frame into a minimal 
    partitura note array row.

    All concurrent ``note_on`` events present in the input frame are merged
    into a single observation (i.e. a frame containing a chord emits one
    observation covering all chord pitches). Frame-level time grouping is
    the ``MidiStream``'s responsibility via ``polling_period``; this
    processor itself is stateless.


    Returns
    -------
    None if the frame has no note_on events. Otherwise a tuple
    ``(pitch_obs, f_time)``
    """

    def __init__(
        self
        ) -> None:
        super().__init__()
        self.id = 0

    def __call__(
        self,
        frame: InputMIDIFrame,
    ) -> Optional[Tuple[np.ndarray, float]]:
        data, f_time = frame
        pitch_obs = []
        
        pitches = []
        note_times = []

        for msg, m_time in data:
            if (
                getattr(msg, "type", "other") == "note_on"
                and getattr(msg, "velocity", 0) > 0
            ):
                pitches.append(msg.note)
                note_times.append(m_time)
        

        if len(pitches) > 1:
               raise ValueError("ParangonarProcessor requires event-based MIDI input with polling_period=None")
                
        if len(pitches) > 0:
            
            fields = [
                        ("onset_sec", "f4"),
                        ("pitch", "i4"),
                        ("id", "U256"),
                    ]
            note_array = []
            for i in range(len(pitches)):
                note_array.append((note_times[i], pitches[i], "n"+str(self.id)))
                self.id += 1

            arr_slice = np.array(note_array, dtype=fields)

            obs_time = min(note_times)

            return arr_slice[0], obs_time
        else:
            return None

    def reset(self) -> None:
        self.id = 0
        